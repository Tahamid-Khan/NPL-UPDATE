<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Registered Users - BIBM Admin</title>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" />
    <style>
        /* Copy the CSS styles from your admin/index.blade.php file here */
        /* Base Styles */
        :root {
            --primary-color: #4361ee;
            --primary-light: #eaefff;
            --secondary-color: #3f37c9;
            --success-color: #0bb07b;
            --info-color: #2196f3;
            --warning-color: #f48c06;
            --danger-color: #e63946;
            --dark-color: #212529;
            --gray-dark: #343a40;
            --gray: #6c757d;
            --gray-light: #f8f9fa;
            --gray-200: #e9ecef;
            --gray-300: #dee2e6;
            --border-color: #e0e0e0;
            --border-radius: 10px;
            --box-shadow: 0 4px 20px rgba(0, 0, 0, 0.05);
            --transition: all 0.3s ease;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Inter', sans-serif;
            background-color: #f5f7fb;
            color: var(--gray-dark);
            min-height: 100vh;
            display: flex;
            overflow-x: hidden;
        }

        a {
            text-decoration: none;
            color: inherit;
        }

        ul {
            list-style: none;
        }

        button {
            cursor: pointer;
            border: none;
            outline: none;
            background: none;
        }

        input,
        select,
        textarea {
            font-family: 'Inter', sans-serif;
            border: 1px solid var(--border-color);
            border-radius: var(--border-radius);
            padding: 10px 15px;
            outline: none;
            transition: var(--transition);
        }

        input:focus,
        select:focus,
        textarea:focus {
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(67, 97, 238, 0.15);
        }

        /* Layout */
        .app-container {
            display: flex;
            width: 100%;
        }

        /* Sidebar */
        .sidebar {
            width: 280px;
            background-color: white;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
            z-index: 100;
            display: flex;
            flex-direction: column;
        }

        .sidebar-header {
            padding: 25px;
            display: flex;
            align-items: center;
            border-bottom: 1px solid var(--border-color);
        }

        .sidebar-header .logo {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary-color);
            display: flex;
            align-items: center;
        }

        .sidebar-header .logo-icon {
            width: 35px;
            height: 35px;
            background-color: var(--primary-color);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            margin-right: 12px;
        }

        .sidebar-content {
            flex: 1;
            padding: 20px 0;
            overflow-y: auto;
        }

        .nav-section {
            margin-bottom: 30px;
        }

        .nav-section-title {
            text-transform: uppercase;
            font-size: 12px;
            color: var(--gray);
            font-weight: 600;
            padding: 0 25px;
            margin-bottom: 15px;
        }

        .nav-item {
            margin-bottom: 5px;
        }

        .nav-link {
            display: flex;
            align-items: center;
            padding: 12px 25px;
            color: var(--gray-dark);
            font-weight: 500;
            border-radius: 0;
            transition: var(--transition);
        }

        .nav-link i {
            width: 20px;
            font-size: 18px;
            margin-right: 15px;
            color: var(--gray);
            transition: var(--transition);
        }

        .nav-link:hover {
            background-color: var(--primary-light);
            color: var(--primary-color);
        }

        .nav-link:hover i {
            color: var(--primary-color);
        }

        .nav-link.active {
            background-color: var(--primary-light);
            color: var(--primary-color);
            font-weight: 600;
        }

        .nav-link.active i {
            color: var(--primary-color);
        }

        /* Main content */
        .main-content {
            flex: 1;
            margin-left: 280px;
            width: calc(100% - 280px);
            transition: var(--transition);
            padding: 30px;
        }

        /* Header */
        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 30px;
        }

        .page-title {
            font-size: 28px;
            font-weight: 700;
            color: var(--dark-color);
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .search-box {
            position: relative;
            width: 280px;
        }

        .search-box input {
            width: 100%;
            padding: 12px 20px 12px 45px;
            border-radius: 8px;
            background-color: white;
            box-shadow: var(--box-shadow);
            border: none;
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: var(--gray);
            font-size: 18px;
        }

        .user-profile {
            display: flex;
            align-items: center;
            gap: 10px;
            cursor: pointer;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 10px;
            overflow: hidden;
        }

        .user-avatar img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .user-info {
            display: flex;
            flex-direction: column;
        }

        .user-name {
            font-weight: 600;
            font-size: 14px;
        }

        .user-role {
            font-size: 12px;
            color: var(--gray);
        }

        /* Event List */
        .event-list-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }

        .event-list-actions {
            display: flex;
            gap: 15px;
        }

        .filter-dropdown {
            position: relative;
        }

        .filter-button {
            padding: 10px 15px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            background-color: white;
            color: var(--gray-dark);
            font-weight: 500;
            box-shadow: var(--box-shadow);
            transition: var(--transition);
        }

        .filter-content {
            position: absolute;
            top: 100%;
            right: 0;
            width: 250px;
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            padding: 15px;
            margin-top: 10px;
            z-index: 10;
            display: none;
        }

        .filter-content.show {
            display: block;
        }

        .filter-group {
            margin-bottom: 15px;
        }

        .filter-title {
            font-weight: 600;
            font-size: 14px;
            margin-bottom: 10px;
        }

        .filter-options {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-check {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-check-input {
            width: 16px;
            height: 16px;
        }

        .form-check-label {
            font-size: 14px;
        }

        .form-button-group {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 15px;
        }

        .btn {
            padding: 8px 15px;
            border-radius: 6px;
            font-weight: 500;
            font-size: 14px;
            transition: var(--transition);
        }

        .btn-secondary {
            background-color: var(--gray-light);
            color: var(--gray-dark);
        }

        .btn-primary {
            background-color: var(--primary-color);
            color: white;
        }

        .calendar-button {
            padding: 10px 15px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            gap: 10px;
            background-color: var(--gray-light);
            color: var(--gray-dark);
            font-weight: 500;
            transition: var(--transition);
        }

        .calendar-button.primary {
            background-color: var(--primary-color);
            color: white;
        }

        .event-table-container {
            background-color: white;
            border-radius: var(--border-radius);
            box-shadow: var(--box-shadow);
            overflow: hidden;
        }

        .event-table {
            width: 100%;
            border-collapse: collapse;
        }

        .event-table th {
            background-color: #f8f9fa;
            padding: 15px 20px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            color: var(--gray-dark);
            border-bottom: 1px solid var(--border-color);
        }

        .event-table td {
            padding: 15px 20px;
            font-size: 14px;
            border-bottom: 1px solid var(--border-color);
        }

        .event-table tr:last-child td {
            border-bottom: none;
        }

        .event-table tr:hover {
            background-color: #f8f9fa;
        }

        .table-title {
            font-weight: 600;
        }

        .table-actions {
            display: flex;
            gap: 10px;
        }

        .table-action {
            width: 32px;
            height: 32px;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: var(--gray-light);
            color: var(--gray);
            transition: var(--transition);
        }

        .table-action:hover {
            background-color: var(--primary-light);
            color: var(--primary-color);
        }

        .table-action.edit:hover {
            background-color: var(--primary-light);
            color: var(--primary-color);
        }

        .table-action.delete:hover {
            background-color: #fdeaea;
            color: var(--danger-color);
        }

        .pagination {
            display: flex;
            justify-content: center;
            padding: 20px;
            gap: 5px;
        }

        .page-item {
            width: 36px;
            height: 36px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            background-color: var(--gray-light);
            color: var(--gray-dark);
            font-weight: 500;
            transition: var(--transition);
            cursor: pointer;
        }

        .page-item:hover {
            background-color: var(--primary-light);
            color: var(--primary-color);
        }

        .page-item.active {
            background-color: var(--primary-color);
            color: white;
            cursor: default;
        }

        .page-item.disabled {
            opacity: 0.5;
            cursor: not-allowed;
            pointer-events: none;
        }

        /* Responsive design */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
                box-shadow: none;
            }

            .sidebar.show {
                transform: translateX(0);
                box-shadow: var(--box-shadow);
            }

            .main-content {
                margin-left: 0;
                width: 100%;
            }
        }

        @media (max-width: 768px) {
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .header-actions {
                width: 100%;
            }

            .search-box {
                width: 100%;
            }

            .event-list-header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }

            .event-list-actions {
                width: 100%;
                justify-content: space-between;
            }

            .event-table th:nth-child(3),
            .event-table td:nth-child(3) {
                display: none;
            }

            .event-table th:nth-child(4),
            .event-table td:nth-child(4) {
                display: none;
            }
        }

        @media (max-width: 576px) {
            .main-content {
                padding: 20px 15px;


}

.event-table th:nth-child(2),
.event-table td:nth-child(2) {
    display: none;
}
}
</style>
</head>

<body>
<div class="app-container">
<!-- Sidebar -->
<div class="sidebar">
<div class="sidebar-header">
    <a href="#" class="logo">
        <div class="logo-icon">
            <i class="fas fa-calendar"></i>
        </div>
        <span>BIBM Event</span>
    </a>
</div>
<div class="sidebar-content">
    <div class="nav-section">
        <div class="nav-section-title">MENU</div>
        <ul class="nav-list">
            <li class="nav-item">
                <a href="<?php echo e(route('adminlogin')); ?>" class="nav-link">
                    <i class="fas fa-chart-pie"></i>
                    <span>Dashboard</span>
                </a>
            </li>
 
            <li class="nav-item">
                <a href="#" class="nav-link nav-link-toggle" data-toggle="events">
                    <i class="fas fa-calendar-day"></i>
                    <span>Events</span>
                </a>
                <ul class="nav-dropdown" id="events-dropdown">
                    <li class="nav-item">
                        <a href="<?php echo e(route('admin.registrations')); ?>" class="nav-link active">
                            <span>Registered Users</span>
                        </a>
                    </li>
                </ul>
            </li>
           
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-chart-line"></i>
                    <span>Reports</span>
                </a>
            </li>
        </ul>
    </div>
    <div class="nav-section">
        <div class="nav-section-title">SETTINGS</div>
        <ul class="nav-list">
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-cog"></i>
                    <span>General Settings</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-user-cog"></i>
                    <span>User Management</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-link">
                    <i class="fas fa-bell"></i>
                    <span>Notifications</span>
                    <span class="badge">3</span>
                </a>
            </li>
        </ul>
    </div>
</div>
</div>

<!-- Main Content -->
<div class="main-content">
<!-- Header -->
<div class="header">
    <h1 class="page-title">Registered Users</h1>
    <div class="header-actions">
        <div class="search-box">
            <i class="fas fa-search"></i>
            <input type="text" placeholder="Search...">
        </div>
        <button class="btn btn-primary" id="download-report">Download Report</button>
        <div class="user-profile">
            <div class="user-avatar">
                <img src="https://prium.github.io/falcon/v3.19.0/assets/img/team/3-thumb.png" alt="User">
            </div>
            <div class="user-info">
                <div class="user-role">Administrator</div>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>

                    <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault();
                                    this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault();
                                    this.closest(\'form\').submit();']); ?>
                        <?php echo e(__('Log Out')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Registered Users Content -->
<div class="event-list-header">
    <h2 class="page-title">Registered Users</h2>
    <div class="event-list-actions">
        <div class="filter-dropdown">
            <button class="filter-button" id="filter-button">
                <i class="fas fa-filter"></i>
                <span>Filter</span>
            </button>
            <div class="filter-content" id="filter-content">
                <div class="filter-group">
                    <div class="filter-title">Institution</div>
                    <div class="filter-options">
                        <div class="form-check">
                            <input type="checkbox" id="filter-all" class="form-check-input" checked>
                            <label for="filter-all" class="form-check-label">All Institutions</label>
                        </div>
                    </div>
                </div>
                <div class="filter-group">
                    <div class="filter-title">Registration Date</div>
                    <div class="filter-options">
                        <div class="form-check">
                            <input type="checkbox" id="filter-recent" class="form-check-input" checked>
                            <label for="filter-recent" class="form-check-label">Recent (Last 7 days)</label>
                        </div>
                        <div class="form-check">
                            <input type="checkbox" id="filter-older" class="form-check-input" checked>
                            <label for="filter-older" class="form-check-label">Older</label>
                        </div>
                    </div>
                </div>
                <div class="form-button-group">
                    <button class="btn btn-secondary">Reset</button>
                    <button class="btn btn-primary">Apply Filters</button>
                </div>
            </div>
        </div>
        <a href="<?php echo e(route('registration.form')); ?>" class="calendar-button primary">
            <i class="fas fa-plus"></i>
            <span>Add New Registration</span>
        </a>
    </div>
</div>
<div class="event-table-container">
    <table class="event-table">
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Institution</th>
                <th>Designation</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td>
                    <div class="table-title"><?php echo e($registration->name); ?></div>
                </td>
                <td><?php echo e($registration->email); ?></td>
                <td><?php echo e($registration->phone); ?></td>
                <td><?php echo e($registration->institution); ?></td>
                <td><?php echo e($registration->designation); ?></td>
                <td>
                    <div class="table-actions">
                        <button class="table-action edit" data-id="<?php echo e($registration->id); ?>">
                            <i class="fas fa-edit"></i>
                        </button>
                        <button class="table-action delete" data-id="<?php echo e($registration->id); ?>">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center">No registrations found</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    <div class="pagination">
        <?php if($registrations->onFirstPage()): ?>
            <span class="page-item disabled">
                <i class="fas fa-chevron-left"></i>
            </span>
        <?php else: ?>
            <a href="<?php echo e($registrations->previousPageUrl()); ?>" class="page-item">
                <i class="fas fa-chevron-left"></i>
            </a>
        <?php endif; ?>
        
        <?php $__currentLoopData = range(1, $registrations->lastPage()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($page == $registrations->currentPage()): ?>
                <span class="page-item active"><?php echo e($page); ?></span>
            <?php elseif($page == 1 || $page == $registrations->lastPage() || abs($page - $registrations->currentPage()) < 3): ?>
                <a href="<?php echo e($registrations->url($page)); ?>" class="page-item"><?php echo e($page); ?></a>
            <?php elseif(abs($page - $registrations->currentPage()) == 3): ?>
                <span class="page-item disabled">...</span>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        <?php if($registrations->hasMorePages()): ?>
            <a href="<?php echo e($registrations->nextPageUrl()); ?>" class="page-item">
                <i class="fas fa-chevron-right"></i>
            </a>
        <?php else: ?>
            <span class="page-item disabled">
                <i class="fas fa-chevron-right"></i>
            </span>
        <?php endif; ?>
    </div>
</div>
</div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
// Toggle dropdown in sidebar
document.querySelectorAll('.nav-link-toggle').forEach(toggle => {
toggle.addEventListener('click', function(e) {
    e.preventDefault();
    const target = this.getAttribute('data-toggle');
    const dropdown = document.getElementById(`${target}-dropdown`);

    this.classList.toggle('active');

    if (dropdown.classList.contains('show')) {
        dropdown.classList.remove('show');
        dropdown.style.height = '0';
    } else {
        dropdown.classList.add('show');
        dropdown.style.height = dropdown.scrollHeight + 'px';
    }
});
});

// Filter dropdown
const filterBtn = document.getElementById('filter-button');
const filterContent = document.getElementById('filter-content');

if (filterBtn && filterContent) {
filterBtn.addEventListener('click', function() {
    filterContent.classList.toggle('show');
});

// Close filter dropdown when clicking outside
document.addEventListener('click', function(e) {
    if (!filterBtn.contains(e.target) && !filterContent.contains(e.target)) {
        filterContent.classList.remove('show');
    }
});
}

// Download report
document.getElementById('download-report').addEventListener('click', function() {
window.location.href = "<?php echo e(route('admin.reports.event-financial')); ?>";
});

// Edit registration
document.querySelectorAll('.table-action.edit').forEach(button => {
button.addEventListener('click', function() {
    const registrationId = this.getAttribute('data-id');
    window.location.href = `/admin/registrations/${registrationId}/edit`;
});
});

// Delete registration
document.querySelectorAll('.table-action.delete').forEach(button => {
button.addEventListener('click', function() {
    if (confirm('Are you sure you want to delete this registration?')) {
        const registrationId = this.getAttribute('data-id');
        
        // Create a form to submit the delete request
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = `/admin/registrations/${registrationId}`;
        form.style.display = 'none';
        
        const csrfToken = document.createElement('input');
        csrfToken.type = 'hidden';
        csrfToken.name = '_token';
        csrfToken.value = '<?php echo e(csrf_token()); ?>';
        
        const method = document.createElement('input');
        method.type = 'hidden';
        method.name = '_method';
        method.value = 'DELETE';
        
        form.appendChild(csrfToken);
        form.appendChild(method);
        document.body.appendChild(form);
        form.submit();
    }
});
});
});
</script>
</body>
</html>
<?php /**PATH D:\BIBM to NPL\resources\views/admin/registrations.blade.php ENDPATH**/ ?>