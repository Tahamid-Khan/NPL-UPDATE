<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Registered Users</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            font-size: 12px;
        }
        .header {
            text-align: center;
            margin-bottom: 20px;
        }
        .header h1 {
            margin-bottom: 5px;
        }
        .filter-info {
            margin-bottom: 15px;
            font-style: italic;
            font-size: 11px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .footer {
            margin-top: 20px;
            text-align: center;
            font-size: 10px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1>NPL Event - Registered Users</h1>
        <p>Generated on <?php echo e(date('F d, Y')); ?></p>
    </div>
    
    <div class="filter-info">
        <?php if($startDate && $endDate): ?>
            Filtered by date: <?php echo e($startDate); ?> to <?php echo e($endDate); ?>

        <?php elseif($searchTerm): ?>
            Search results for: "<?php echo e($searchTerm); ?>"
        <?php else: ?>
            Showing all registrations
        <?php endif; ?>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Institution</th>
                <th>Designation</th>
                <th>Registered On</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $registrations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($registration->name); ?></td>
                <td><?php echo e($registration->email); ?></td>
                <td><?php echo e($registration->phone); ?></td>
                <td><?php echo e($registration->institution); ?></td>
                <td><?php echo e($registration->designation); ?></td>
                <td><?php echo e($registration->created_at->format('M d, Y')); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" style="text-align: center;">No registrations found</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
    
    <div class="footer">
        <p>© <?php echo e(date('Y')); ?> NPL Event Management System</p>
    </div>
</body>
</html>
<?php /**PATH D:\BIBM to NPL\resources\views/admin/pdf/registrations.blade.php ENDPATH**/ ?>