<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Event Financial Report</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        .header {
            text-align: center;
            margin-bottom: 30px;
        }
        .logo {
            font-size: 24px;
            font-weight: bold;
            color: #4361ee;
            margin-bottom: 10px;
        }
        .report-title {
            font-size: 22px;
            margin-bottom: 5px;
        }
        .report-date {
            font-size: 14px;
            color: #666;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        .amount {
            text-align: right;
        }
        .total-row {
            font-weight: bold;
            background-color: #f8f9fa;
        }
        .profit {
            color: #0bb07b;
        }
        .loss {
            color: #e63946;
        }
        .summary {
            margin-top: 30px;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 5px;
        }
        .summary-title {
            font-size: 18px;
            margin-bottom: 15px;
        }
        .summary-item {
            display: flex;
            justify-content: space-between;
            margin-bottom: 10px;
        }
        .footer {
            margin-top: 50px;
            text-align: center;
            font-size: 12px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="logo">BIBM Event Management</div>
        <div class="report-title">Event Financial Report</div>
        <div class="report-date">Generated on: <?php echo e($generatedDate); ?></div>
    </div>
    
    <table>
        <thead>
            <tr>
                <th>Event Name</th>
                <th>Type</th>
                <th>Date</th>
                <th class="amount">Income (৳)</th>
                <th class="amount">Expenses (৳)</th>
                <th class="amount">Profit/Loss (৳)</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($event['name']); ?></td>
                <td><?php echo e($event['type']); ?></td>
                <td><?php echo e($event['date']); ?></td>
                <td class="amount"><?php echo e(number_format($event['income'])); ?></td>
                <td class="amount"><?php echo e(number_format($event['expenses'])); ?></td>
                <td class="amount <?php echo e($event['profit'] >= 0 ? 'profit' : 'loss'); ?>">
                    <?php echo e(number_format($event['profit'])); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <tr class="total-row">
                <td colspan="3">Total</td>
                <td class="amount"><?php echo e(number_format($totalIncome)); ?></td>
                <td class="amount"><?php echo e(number_format($totalExpenses)); ?></td>
                <td class="amount <?php echo e($totalProfit >= 0 ? 'profit' : 'loss'); ?>">
                    <?php echo e(number_format($totalProfit)); ?>

                </td>
            </tr>
        </tbody>
    </table>
    
    <div class="summary">
        <div class="summary-title">Financial Summary</div>
        <div class="summary-item">
            <span>Total Income:</span>
            <span>৳ <?php echo e(number_format($totalIncome)); ?></span>
        </div>
        <div class="summary-item">
            <span>Total Expenses:</span>
            <span>৳ <?php echo e(number_format($totalExpenses)); ?></span>
        </div>
        <div class="summary-item">
            <span>Net Profit/Loss:</span>
            <span class="<?php echo e($totalProfit >= 0 ? 'profit' : 'loss'); ?>">
                ৳ <?php echo e(number_format($totalProfit)); ?>

            </span>
        </div>
    </div>
    
    <div class="footer">
        <p>This is an automatically generated report from BIBM Event Management System.</p>
        <p>© <?php echo e(date('Y')); ?> BIBM Event Management. All rights reserved.</p>
    </div>
</body>
</html>
<?php /**PATH D:\BIBM\BIBM\resources\views/reports/event_financial.blade.php ENDPATH**/ ?>